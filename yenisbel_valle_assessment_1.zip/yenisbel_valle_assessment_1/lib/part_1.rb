def is_prime?(number)
    if number <= 1 
        return false
    end    
    (2...number).each do |num|
        if number % num == 0
            return false
        end
    end
    true
end

def nth_prime(number)
    i = 0 
    ans = []
    while i < 2000
        if is_prime?(i)
            ans << i 
        end 
    i = i + 1 
    end 
   p ans[number - 1]    
end

p nth_prime(300)

def prime_range(num1, num2)
    arry_prime = []
    (num1..num2).each do |number|
        if is_prime?(number)
            arry_prime.push(number)
        end
    end
    return arry_prime
end